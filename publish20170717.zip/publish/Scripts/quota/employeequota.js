﻿function bindQuotaPageEvent() {
    $(document).on('click', '.quota-add-btn', function () {
        $('.addEmployeeQuota').show();
    });

    $(document).on('click', '.quota-cancel-btn', function () {
        $('.quota-amount').val("");
        $('.addEmployeeQuota').hide();
    });

    $(document).on('click', '.quota-save-btn', function () {
        if (validateInputs()) {
            var employeeQuota = {};
            employeeQuota.Date = $('.quota-date').val();
            employeeQuota.UserID = $('#EmployeeId').val();
            employeeQuota.Quota = $('.quota-amount').val();

            $.ajax({
                url: "/Quota/AddEmployeeQuotaInfo",
                data: { val: JSON.stringify(employeeQuota) },
                type: "POST",
                success: function (data) {
                    if (data = "success") {
                        alert("保存成功");
                        $('.addEmployeeQuota').hide();
                        $('.quota-amount').val("");
                        reloadEmployeeQuotaDetails();
                    }
                    else
                        alert("保存失败");
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Save employee quota info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            });
        }
    });
}

function reloadEmployeeQuotaDetails() {
    $.ajax({
        url: "/Quota/ReloadEmployeeQuotaDetails",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTable('#DashboardDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload employee quota info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function validateInputs() {
    var quota = $('.quota-amount').val();

    if (quota.Trim() == "") {
        alert("请填写配资金额");
        return false;
    }
    else if (!IsNumber(quota)) {
        alert('请输入正确的配资金额');
        return false;
    }
    else {
        if (quota < 0) {
            alert('请输入正确的配资金额');
            return false;
        }
    }
    return true;
}