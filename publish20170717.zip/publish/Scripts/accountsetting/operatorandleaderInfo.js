﻿var isOperatorLeaderEdit = false;
var operatorLeaderEditId = 0;
var operatorLeaderGroupId = 0;
var userId = null;
var addOrEdit = "";

var isGroupEdit = false;
var groupEditId = 0;
var gName = "";
var groupAddOrEdit = "";

function bindOperatorLeadManagerEvent() {
    $(document).on('click', '.operatorleader-add-btn', function () {
        addOrEdit = "add";
        if ($('#OperatorLeader option').size() <= 1)
            alert("没有新员工可以添加分组设置");
        else {
            clearAllValues();
            $('#ol_username').prop('style', 'display:none;');
            $('#OperatorLeader').prop('style', 'display:block;');
            $('.addOperatorLeaderDiv').show();
        }
    });

    $(document).on('click', '.group-add-btn', function () {
        groupAddOrEdit = "add";
        clearGroupAllValues();
        $('.addGroupDiv').show();

    });

    $(document).on('click', '.operatorleader-cancel-btn', function () {
        addOrEdit = "";
        clearAllValues();
        $('.addOperatorLeaderDiv').hide();
    });

    $(document).on('click', '.group-cancel-btn', function () {
        groupAddOrEdit = "";
        clearGroupAllValues();
        $('.addGroupDiv').hide();
    });

    $(document).on('click', '.editAction', function () {
        addOrEdit = "edit";
        $('.addOperatorLeaderDiv').show();
        editOperatorLeader(this);
    });

    $(document).on('click', '.editActionGroup', function () {
        groupAddOrEdit = "edit";
        $('.addGroupDiv').show();
        editGroup(this);
    });

    $(document).on('click', '.operatorleader-save-btn', function () {
        saveOperatorLeader();
    });

    $(document).on('click', '.group-save-btn', function () {
        saveGroup();
    });
}

function saveOperatorLeader() {
    if (validateInputs()) {
        var operatorLeaderInfo = getOperatorLeaderInfoObj()
        var operatorLeaderInfoJsonStr = JSON.stringify(operatorLeaderInfo);
        $.ajax({
            url: "/AccountSetting/SaveOperatorLeader",
            data: { OperatorLeaderJsonStr: operatorLeaderInfoJsonStr, IsEdit: isOperatorLeaderEdit },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    $('#OperatorLeader option[value=' + operatorLeaderInfo.UserID + ']').remove();
                    reloadOperatorLeader();
                    clearAllValues();
                    $('.addOperatorLeaderDiv').hide();
                    //location.reload();
                }
                else if (data == 'duplicate')
                    alert("保存失败，该组组长已存在！");
                else
                    alert("保存失败，数据异常！");
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Save operator or leader info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }   
}

function saveGroup() {
    if (validateGroupInputs()) {
        var groupInfo = getGroupInfoObj()
        var groupInfoJsonStr = JSON.stringify(groupInfo);
        $.ajax({
            url: "/AccountSetting/SaveGroup",
            data: { GroupJsonStr: groupInfoJsonStr, IsEdit: isGroupEdit },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    reloadGroup();
                    clearGroupAllValues();
                    $('.addGroupDiv').hide();
                    //location.reload();
                }
                else if (data == 'duplicate')
                    alert("保存失败，组名已存在！");
                else
                    alert("保存失败，数据异常！");
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Save group info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
}

function reloadOperatorLeader() {
    $.ajax({
        url: "/AccountSetting/ReloadOperatorLeader",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTable('#OperatorLeaderGroupDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload operator or leader info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadGroup() {
    $.ajax({
        url: "/AccountSetting/ReloadGroup",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content2').html(data);
            initCommonDataTable('#GroupDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload group info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function validateInputs() {
    var valResult = true;
    var operatorOrLeaderUserID = $('#OperatorLeader').val();
    var groupID = $('#OperatorLeaderGroup').val();

    if (userId == null)//add
    {
        if (operatorOrLeaderUserID.Trim() == "") {
            valResult = false;
            alert("请填选择一个用户名称");
        }
        else if (groupID.Trim() == "") {
            valResult = false;
            alert("请选择一个组");
        }
    }
    else//edit
    {
        if (groupID.Trim() == "") {
            valResult = false;
            alert("请选择一个组");
        }
        else if (groupID == operatorLeaderGroupId) {
            valResult = false;
            alert("未做更改");
        }
    }
    return valResult;
}

function validateGroupInputs() {
    var valResult = true;
    var groupName = $('#g_groupname').val();
    var len = 0;
    for (var i = 0; i < groupName.length; i++) {
        var a = groupName.charAt(i);
        if (a.match(/[^\x00-\xff]/ig) != null) {
            len += 2;
        }
        else {
            len += 1;
        }
    }
    if (groupName.Trim() == "") {
        valResult = false;
        alert("请填写一个组名");
    }
    else if (len > 50) {
        valResult = false;
        alert("组名过长");
    }
    else if (gName == groupName) {
        valResult = false;
        alert("未做更改");
    }
    return valResult
}

function getOperatorLeaderInfoObj() {
    var operatorLeaderInfo = new Object();
    if (isOperatorLeaderEdit) {
        operatorLeaderInfo.ID = operatorLeaderEditId;
    }
    if (addOrEdit == "add")
        operatorLeaderInfo.UserID = $('#OperatorLeader').val();
    else
        operatorLeaderInfo.UserID = userId;
    operatorLeaderInfo.GroupID = $('#OperatorLeaderGroup').val();
    // other fields
    return operatorLeaderInfo;
}

function getGroupInfoObj() {
    var groupInfo = new Object();
    if (isGroupEdit) {
        groupInfo.ID = groupEditId;
    }
    groupInfo.GroupName = $('#g_groupname').val();
    // other fields
    return groupInfo;
}

function editOperatorLeader(obj) {
    var rowObj = $(obj).closest('tr');
    isOperatorLeaderEdit = true;
    operatorLeaderEditId = $(rowObj).data('olid');
    operatorLeaderGroupId = $(rowObj).data('groupid');
    userId = $(rowObj).data('userid')
    $('#OperatorLeader').prop('style', 'display:none;');
    $('#ol_username').prop('style', 'display:block;');
    $('#ol_username').val($(rowObj).data('username'));
    $('#ol_username').prop('disabled', 'disabled');
    $('#OperatorLeaderGroup').val($(rowObj).data('groupid'));
}

function editGroup(obj) {
    var rowObj = $(obj).closest('tr');
    isGroupEdit = true;
    groupEditId = $(rowObj).data('gid');
    gName = $(rowObj).data('ggroupname');
    $('#g_groupname').val($(rowObj).data('ggroupname'));

}

function clearAllValues() {
    $('#OperatorLeader').removeAttr('disabled');
    $('#OperatorLeader').val("");
    $('#OperatorLeaderGroup').val("");
    isOperatorLeaderEdit = false;
    operatorLeaderEditId = 0;
    operatorLeaderGroupId = 0;
}

function clearGroupAllValues() {
    $('#g_groupname').val("");
    isGroupEdit = false;
    groupEditId = 0;
    gName = "";
}