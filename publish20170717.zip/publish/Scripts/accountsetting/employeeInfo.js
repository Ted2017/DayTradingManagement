﻿var psId = null;
var userId = null;

function bindProfitShareManagerEvent() {
    $(document).on('click', '.profitshare-run-btn', function () {
        $.ajax({
            url: "/AccountSetting/CalculateProfitShare",
            data: {},
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    reloadProfitShare();
                    clearAllValues();
                    $('.addProfitShareDiv').hide();
                }
                else
                    alert("计算失败，数据异常!");
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Calculate error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    });

    $(document).on('click', '.profit-cancel-btn', function () {
        clearAllValues();
        $('.addProfitShareDiv').hide();
    });

    $(document).on('click', '.editAction', function () {
        $('.addProfitShareDiv').show();
        editProfitShare(this);
    });

    $(document).on('click', '.profit-save-btn', function () {
        saveProfitShare();
    });

    $(document).on('change', '#traderLevelId', function () {
        var tlId = +$('#traderLevelId').val();
        $.ajax({
            url: "/AccountSetting/GetTraderLevelInfoById",
            data: { traderLevelId: tlId },
            type: "POST",
            success: function (data) {
                var jsObject = eval(data);
                $('.profit-mb').val(jsObject.BaseLine);
                $('.profit-ma').val(jsObject.Insurance);
                $('.profit-mo').val(jsObject.Other);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Save employee info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    });
}

function saveProfitShare() {
    if (validateInputs()) {
        var profitShareInfo = getProfitShareInfoObj()
        var profitShareInfoJsonStr = JSON.stringify(profitShareInfo);
        $.ajax({
            url: "/AccountSetting/SaveProfitShare",
            data: { ProfitShareJsonStr: profitShareInfoJsonStr },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    //$('#LoginUserId option[value=' + profitShareInfo.UserID + ']').remove();
                    reloadProfitShare();
                    clearAllValues();
                    $('.addProfitShareDiv').hide();
                    //location.reload();
                }
                else
                    alert("保存失败，数据异常!");
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Save employee info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
    else {
        //to-do
    }
}

function reloadProfitShare() {
    $.ajax({
        url: "/AccountSetting/ReloadProfitShare",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTable('#ProfitShareDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload employee info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function validateInputs() {
    var valResult = true;

    var monthBase = $('.profit-mb').val();
    var monthAllowance = $('.profit-ma').val();
    var monthOthers = $('.profit-mo').val();

    if (monthBase.Trim() == "" || !IsNumber(monthBase.Trim())) {
        valResult = false;
        alert("请填写正确的底薪");
    }
    else if (monthAllowance.Trim() == "" || !IsNumber(monthAllowance.Trim())) {
        valResult = false;
        alert("请填写正确的补助");
    }
    else if (monthOthers.Trim() == "" || !IsNumber(monthOthers.Trim())) {
        valResult = false;
        alert("请填写正确的其它");
    }
    return valResult;
}

function getProfitShareInfoObj() {
    var profitShareInfo = new Object();
    profitShareInfo.ShareID = psId;
    profitShareInfo.UserID = userId;
    profitShareInfo.TraderLevelStandardID = $('#traderLevelId').val();
    profitShareInfo.MonthBase = $('.profit-mb').val();
    profitShareInfo.MonthAllowance = $('.profit-ma').val();
    profitShareInfo.MonthOthers = $('.profit-mo').val();

    return profitShareInfo;
}

function editProfitShare(obj) {
    var rowObj = $(obj).closest('tr');
    psId = $(rowObj).data('shareid');
    userId = $(rowObj).data('userid');
    var tlid = $(rowObj).data('traderlevelid');

    $('#ps_username').prop('disabled', 'disabled');
    $('.profit-sp').prop('disabled', 'disabled');
    $('#traderLevelId option[value=' + tlid + ']').prop("selected", true);
    $('#ps_username').val($(rowObj).data('username'));
    $('.profit-mb').val($(rowObj).data('monthbase'));
    $('.profit-sp').val($(rowObj).data('sharepercent'));
    $('.profit-ma').val($(rowObj).data('monthallowance'));
    $('.profit-mo').val($(rowObj).data('monthothers'));

}

function clearAllValues() {
    $('#ps_username').val("");
    $('.profit-mb').val("");
    $('.profit-sp').val("");
    $('.profit-ma').val("");
    $('.profit-mo').val("");
}