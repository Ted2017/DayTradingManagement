﻿function bindUploadDailyDealOrderEvent() {
    $(document).on('click', '.data-upload-action', function () {
        uploadDailyDealOrderDataFile(this);
    });

    $(document).on('click', '.file-remove-action', function () {
        removeChooseFile(this);
    });
}

function uploadDailyDealOrderDataFile(obj) {
    var fileInputObj = $(obj).parent().find('.trading-order-upload');
    if (fileInputObj.val() == '') {
        alert('请选择一个正确的数据文件');
    }
    else {
        $('.bg').fadeIn(200);
        $('.loadingcontent').fadeIn(400);
        var formData = new FormData();
        formData.append('resourcetype', fileInputObj.data('resourcetype'));
        formData.append('filename', fileInputObj[0].files[0]);
        $.ajax({
            url: "/Stock/UploadDailyDealOrderDataFile",
            data: formData,
            type: "POST",
            cache: false,
            processData: false,
            contentType: false,
            success: function (data) {
                if (data == 'success') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    alert('上传成功');
                    removeChooseFile(obj);
                }
                else if (data == 'failed') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    alert('上传失败，重复数据');
                    removeChooseFile(obj);
                }
                else {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    alert(data);
                    removeChooseFile(obj);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.bg').fadeOut(800);
                $('.loadingcontent').fadeOut(800);
                alert("Upload daily deal order data file error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
}

function removeChooseFile(obj) {
    $(obj).parent().find('.trading-order-upload').val('');
}


function bindPickupDailyDealOrderEvent(userid) {
    $(document).on('click', '.pickup-save-btn', function () {
        if ($("#DailyDealOrderDataTbl").find(":checkbox:checked").length != 0) {
            var dealOrders = [];
            $("#DailyDealOrderDataTbl").find(":checkbox:checked").each(function () {
                var cn = $(this).parent().parent().find("td:eq(6)").text();
                var dealOrder = {};
                dealOrder.ContractNumber = cn;
                dealOrder.StockOperatorUserID = userid;
                dealOrders.push(dealOrder);
            });

            $.ajax({
                url: "/Stock/BindDealOrderWithOperater",
                data: { val: JSON.stringify(dealOrders) },
                type: "POST",
                success: function (data) {
                    if (data == 'success') {
                        alert('保存成功');
                        reloadDailyDealOrder();
                        reloadMyDailyDealOrder();
                        //window.location.reload();
                    }
                    else {
                        alert('保存失败');
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Binding all deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            })
        }
        else
            alert("请至少选中一条记录");
    });
}

function deletePickupDailyDealOrderEvent(userid) {
    $(document).on('click', '.pickup-delete-btn', function () {
        if ($("#DailyDealOrderDataTbl2").find(":checkbox:checked").length != 0) {
            var dealOrders = [];
            $("#DailyDealOrderDataTbl2").find(":checkbox:checked").each(function () {
                var cn = $(this).parent().parent().find("td:eq(6)").text();
                var dealOrder = {};
                dealOrder.ContractNumber = cn;
                dealOrder.StockOperatorUserID = userid;
                dealOrders.push(dealOrder);
            });

            $.ajax({
                url: "/Stock/DeleteDealOrderWithOperater",
                data: { val: JSON.stringify(dealOrders) },
                type: "POST",
                success: function (data) {
                    if (data == 'success') {
                        alert('撤销成功');
                        reloadMyDailyDealOrder();
                        reloadDailyDealOrder();
                        //window.location.reload();
                    }
                    else {
                        alert('撤销成功');
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Deleting my deal order with error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            })
        }
        else
            alert("请至少选中一条记录");
    });
}

function reloadDailyDealOrder() {
    $.ajax({
        url: "/Stock/ReloadPickupDailyDealOrder",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTable('#DailyDealOrderDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload daily deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadMyDailyDealOrder() {
    $.ajax({
        url: "/Stock/ReloadMyPickupDailyDealOrder",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content2').html(data);
            initCommonDataTable('#DailyDealOrderDataTbl2');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload daily deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}