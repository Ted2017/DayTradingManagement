﻿function bindUploadTradingOrderEvent() {
    $(document).on('click', '.data-upload-action', function () {
        uploadTradingOrderDataFile(this);
    });

    $(document).on('click', '.file-remove-action', function () {
        removeChooseFile(this);
    });
}

function uploadTradingOrderDataFile(obj) {
    var fileInputObj = $(obj).parent().find('.trading-order-upload');
    if (fileInputObj.val() == '') {
        alert('请选择一个正确的数据文件');
    }
    else {
        $('.bg').fadeIn(200);
        $('.loadingcontent').fadeIn(400);
        var formData = new FormData();
        formData.append('resourcetype', fileInputObj.data('resourcetype'));
        formData.append('filename', fileInputObj[0].files[0]);
        $.ajax({
            url: "/Stock/UploadTradingOrderDataFile",
            data: formData,
            type: "POST",
            cache: false,
            processData: false,
            contentType: false,
            success: function (data) {
                if (data == 'success') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    alert('上传成功');
                    removeChooseFile(obj);
                }
                else if (data == 'failed') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    alert('上传失败，重复数据');
                    removeChooseFile(obj);
                }
                else {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    alert(data);
                    removeChooseFile(obj);
                } 
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.bg').fadeOut(800);
                $('.loadingcontent').fadeOut(800);
                alert("Upload trading order data file error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
}

function removeChooseFile(obj) {
    $(obj).parent().find('.trading-order-upload').val('');
}


