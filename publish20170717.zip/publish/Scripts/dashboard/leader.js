﻿function bindDashboardPageEvent() {
    $(document).on('click', '#reloadBtnMPP', function () {
        reloadMyProfitPercentPartial();
    });
}

function reloadMyProfitPercentPartial() {
    var tempDate = $("#MonthDate").val();
    $.ajax({
        url: "/Dashboard/ReloadLeaderMyProfitPercentPartial",
        data: { SelectedMonth: tempDate },
        type: "POST",
        success: function (data) {
            $('.dashboard-partial').html(data);
            initCommonDataTable('#DashboardDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload dashboard partial error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}