﻿var isTraderLevelEdit = false;
var traderLevelEditId = 0;
var addOrEdit = "";

function bindTraderLevelManagerEvent() {
    $(document).on('click', '.trader-add-btn', function () {
        addOrEdit = "add";
        clearAllValues();
        $('.addTraderLevelDiv').show();
    });

    $(document).on('click', '.trader-cancel-btn', function () {
        addOrEdit = "";
        clearAllValues();
        $('.addTraderLevelDiv').hide();
    });

    $(document).on('click', '.editAction', function () {
        addOrEdit = "edit";
        $('.addTraderLevelDiv').show();
        editTraderLevel(this);
    });

    $(document).on('click', '.trader-save-btn', function () {
        saveTraderLevel();
    });
}

function saveTraderLevel() {
    if (validateInputs()) {
        var traderLevelInfo = getTraderLevelInfoObj()
        var traderLevelInfoJsonStr = JSON.stringify(traderLevelInfo);
        $.ajax({
            url: "/AccountSetting/SaveTraderLevel",
            data: { TraderLevelJsonStr: traderLevelInfoJsonStr, IsEdit: isTraderLevelEdit },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    reloadTraderLevel();
                    clearAllValues();
                    $('.addTraderLevelDiv').hide();
                    //location.reload();
                }
                else if (data == 'duplicate')
                    window.wxc.xcConfirm("保存失败，交易员级别已存在!", window.wxc.xcConfirm.typeEnum.error);
                else
                    window.wxc.xcConfirm("保存失败，数据异常!", window.wxc.xcConfirm.typeEnum.error);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Save trader level info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
    else {
        //to-do
    }
}

function reloadTraderLevel() {
    $.ajax({
        url: "/AccountSetting/ReloadTraderLevel",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTableForTraderLevel('#TraderLevelDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload trader level info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function validateInputs() {
    var valResult = true;

    var traderLevel = $('.trader-tl').val();
    var tradingAmount = $('.trader-ta').val();
    var tradingDays = $('.trader-td').val();
    var tradingProfits = $('.trader-tp').val();
    var profitBench = $('.trader-pb').val();
    var profitPercent = $('.trader-pp').val();
    var achievementPercent = $('.trader-ap').val();
    var baseline = $('.trader-base').val();
    var insurance = $('.trader-insurance').val();
    var other = $('.trader-other').val();

    if (traderLevel.Trim() == "") {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的交易员级别", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (tradingAmount.Trim() == "" || !IsNumber(tradingAmount.Trim())) {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的交易资产", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (tradingDays.Trim() == "" || !IsNumber(tradingDays.Trim())) {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的交易天数", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (tradingProfits.Trim() == "" || !IsNumber(tradingProfits.Trim())) {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的盈利", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (profitBench.Trim() == "") {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的盈利定级", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (profitPercent.Trim() == "" || +(profitPercent.Trim()) > 100 || +(profitPercent.Trim()) < 0) {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的业绩分成", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (achievementPercent.Trim() == "" || +(achievementPercent.Trim()) > 100 || +(achievementPercent.Trim()) < 0) {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的达成分成", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (baseline.Trim() == "" || !IsNumber(baseline.Trim())) {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的底薪", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (insurance.Trim() == "" || !IsNumber(insurance.Trim())) {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的保险", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (other.Trim() == "" || !IsNumber(other.Trim())) {
        valResult = false;
        window.wxc.xcConfirm("请填写正确的其它", window.wxc.xcConfirm.typeEnum.error);
    }
    return valResult;
}

function getTraderLevelInfoObj() {
    var traderLevelInfo = new Object();
    if (isTraderLevelEdit) {
        traderLevelInfo.ID = traderLevelEditId;
    }

    traderLevelInfo.TraderLevel = $('.trader-tl').val();
    traderLevelInfo.TradingAmount = $('.trader-ta').val();
    traderLevelInfo.TradingDays = $('.trader-td').val();
    traderLevelInfo.TradingProfits = $('.trader-tp').val();
    traderLevelInfo.ProfitBench = $('.trader-pb').val();
    traderLevelInfo.PerformancePercent = $('.trader-pp').val();
    traderLevelInfo.AchievementPercent = $('.trader-ap').val();
    traderLevelInfo.Baseline = $('.trader-base').val();
    traderLevelInfo.Insurance = $('.trader-insurance').val();
    traderLevelInfo.Other = $('.trader-other').val();

    // other fields
    return traderLevelInfo;
}

function editTraderLevel(obj) {
    var rowObj = $(obj).closest('tr');
    isTraderLevelEdit = true;
    traderLevelEditId = $(rowObj).data('id');

    $('.trader-tl').val($(rowObj).data('tlevel'));
    $('.trader-ta').val($(rowObj).data('tamount'));
    $('.trader-td').val($(rowObj).data('tdays'));
    $('.trader-tp').val($(rowObj).data('tprofits'));
    $('.trader-pb').val($(rowObj).data('tpbench'));
    $('.trader-pp').val($(rowObj).data('tppercent'));
    $('.trader-ap').val($(rowObj).data('tapercent'));
    $('.trader-base').val($(rowObj).data('tbase'));
    $('.trader-insurance').val($(rowObj).data('tinsurance'));
    $('.trader-other').val($(rowObj).data('tother'));
}

function clearAllValues() {
    $('.trader-tl').val("");
    $('.trader-ta').val("");
    $('.trader-td').val("");
    $('.trader-tp').val("");
    $('.trader-pb').val("");
    $('.trader-pp').val("");
    $('.trader-ap').val("");
    $('.trader-base').val("");
    $('.trader-insurance').val("");
    $('.trader-other').val("");
    isTraderLevelEdit = false;
    traderLevelEditId = 0;
}