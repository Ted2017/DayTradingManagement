﻿var dailyDeailOrderId = 0;
var contractNumber = 0;

function bindUploadDailyDealOrderEvent() {
    $(document).on('click', '.data-upload-action', function () {
        uploadDailyDealOrderDataFile(this);
    });

    $(document).on('click', '.file-remove-action', function () {
        removeChooseFile(this);
    });
}

function uploadDailyDealOrderDataFile(obj) {
    var fileInputObj = $(obj).parent().find('.trading-order-upload');
    if (fileInputObj.val() == '') {
        window.wxc.xcConfirm("请选择一个正确的数据文件", window.wxc.xcConfirm.typeEnum.error);
    }
    else {
        $('.bg').fadeIn(200);
        $('.loadingcontent').fadeIn(400);
        var formData = new FormData();
        formData.append('resourcetype', fileInputObj.data('resourcetype'));
        formData.append('filename', fileInputObj[0].files[0]);
        $.ajax({
            url: "/Stock/UploadDailyDealOrderDataFile",
            data: formData,
            type: "POST",
            cache: false,
            processData: false,
            contentType: false,
            success: function (data) {
                if (data == 'success') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传成功", window.wxc.xcConfirm.typeEnum.success);
                    removeChooseFile(obj);
                }
                else if (data == 'failed') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传失败，重复数据", window.wxc.xcConfirm.typeEnum.error);
                    removeChooseFile(obj);
                }
                else if (data == 'errorNull') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传失败，文件为空", window.wxc.xcConfirm.typeEnum.error);
                    removeChooseFile(obj);
                }
                else if (data == 'errorWrongHTDataFile') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传失败，请选择正确的海通证券当日成交文件", window.wxc.xcConfirm.typeEnum.error);
                    removeChooseFile(obj);
                }
                else if (data == 'errorWrongZSDataFile') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传失败，请选择正确的招商证券当日成交文件", window.wxc.xcConfirm.typeEnum.error);
                    removeChooseFile(obj);
                }
                else if (data == 'missStock') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传失败，无持股记录", window.wxc.xcConfirm.typeEnum.error);
                    removeChooseFile(obj);
                }
                else {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    alert(data);
                    removeChooseFile(obj);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.bg').fadeOut(800);
                $('.loadingcontent').fadeOut(800);
                alert("Upload daily deal order data file error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
}

function removeChooseFile(obj) {
    $(obj).parent().find('.trading-order-upload').val('');
}


function bindPickupDailyDealOrderEvent(userid) {
    $(document).on('click', '.pickup-save-btn', function () {
        if ($("#DailyDealOrderDataTbl").find(":checkbox:checked").length != 0) {
            var dealOrders = [];
            $("#DailyDealOrderDataTbl").find(":checkbox:checked").each(function () {
                var cn = $(this).parent().parent().find("td:eq(8)").text();
                var dealOrder = {};
                dealOrder.ContractNumber = cn;
                dealOrder.StockOperatorUserID = userid;
                dealOrders.push(dealOrder);
            });

            $.ajax({
                url: "/Stock/BindDealOrderWithOperater",
                data: { val: JSON.stringify(dealOrders) },
                type: "POST",
                success: function (data) {
                    if (data == 'success') {
                        reloadDailyDealOrder();
                        reloadMyDailyDealOrder();
                        reloadMyDailyDealOrderSummary();
                        window.wxc.xcConfirm("保存成功", window.wxc.xcConfirm.typeEnum.success);
                        //window.location.reload();
                    }
                    else {
                        window.wxc.xcConfirm("保存失败", window.wxc.xcConfirm.typeEnum.error);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Binding all deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            })
        }
        else
            window.wxc.xcConfirm("请至少选中一条记录", window.wxc.xcConfirm.typeEnum.error);
    });

    $(document).on('click', '.unfoldAction', function () {
        $(".unfold-contract-editdiv").hide();
        contractNumber = +$(this).parent().parent().find("td:eq(8)").text();
        if (contractNumber != 0) {
            $.ajax({
                url: "/Stock/GetMyDailyDealOrderByContractNumber",
                data: { val: contractNumber },
                type: "POST",
                success: function (data) {
                    $('.admin-content4').html(data);
                    initCommonDataTable('#DailyDealOrderDataTbl4');
                    $(".unfold-contract").show();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Load daily deal order by contract number error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            });
        }
        else {
            //to do...
        }
    });

    $(document).on('click', '.splitAction', function () {
        $('.unfold-contract-editdiv').show();
        dailyDeailOrderId = +$(this).closest('tr').data("ddoid");
        $('.stock-name').text($(this).parent().parent().find("td:eq(1)").text());
        $('.trading-date').text($(this).parent().parent().find("td:eq(2)").text());
        $('.trading-type').text($(this).parent().parent().find("td:eq(3)").text());
        $('.trading-price').text($(this).parent().parent().find("td:eq(6)").text());
        $('.trading-number').text($(this).parent().parent().find("td:eq(5)").text());
    });

    $(document).on('click', '.split-save-btn', function () {
        if (dailyDeailOrderId != 0) {
            var tradingNumber = $('.split-number').val();
            if (tradingNumber.Trim() == "" || !(/^[0-9]*[1-9][0-9]*$/.test(tradingNumber.Trim()))) {
                window.wxc.xcConfirm("请填写正确的拆分股数", window.wxc.xcConfirm.typeEnum.error);
            }
            else if (tradingNumber > +$('.trading-number').text()) {
                window.wxc.xcConfirm("拆分股数不能大于成交数量", window.wxc.xcConfirm.typeEnum.error);
            }
            else {
                var uid = +$('#OperatorId').val();
                $.ajax({
                    url: "/Stock/SplitDailyDealOrder",
                    data: { val1: dailyDeailOrderId, val2: uid, val3: tradingNumber },
                    type: "POST",
                    success: function (data) {
                        $('.unfold-contract-editdiv').hide();
                        $('.unfold-contract').hide();
                        //reloadDailyDealOrderByContractNumber(contractNumber);
                        reloadMyDailyDealOrder();
                        reloadMyDailyDealOrderSummary();
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        alert("Split error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                    }
                });
            }
        }
        else {
            //to do...
        }
    });

    $(document).on('click', '.split-cancel-btn', function () {
        $('.split-number').val("");
        $('#OperatorId option:first').prop('selected', 'selected');
        $('.unfold-contract-editdiv').hide();
    });
}

function deletePickupDailyDealOrderEvent(userid) {
    $(document).on('click', '.pickup-delete-btn', function () {
        $(".unfold-contract").hide();
        $(".unfold-contract-editdiv").hide();
        if ($("#DailyDealOrderDataTbl2").find(":checkbox:checked").length != 0) {
            var dealOrders = [];
            $("#DailyDealOrderDataTbl2").find(":checkbox:checked").each(function () {
                var cn = $(this).parent().parent().find("td:eq(8)").text();
                var dealOrder = {};
                dealOrder.ContractNumber = cn;
                dealOrder.StockOperatorUserID = userid;
                dealOrders.push(dealOrder);
            });

            $.ajax({
                url: "/Stock/DeleteDealOrderWithOperater",
                data: { val: JSON.stringify(dealOrders) },
                type: "POST",
                success: function (data) {
                    if (data == 'success') {
                        reloadMyDailyDealOrder();
                        reloadDailyDealOrder();
                        reloadMyDailyDealOrderSummary();
                        window.wxc.xcConfirm("撤销成功", window.wxc.xcConfirm.typeEnum.success);
                        //window.location.reload();
                    }
                    else {
                        window.wxc.xcConfirm("撤销失败", window.wxc.xcConfirm.typeEnum.error);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Deleting my deal order with error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            })
        }
        else
            window.wxc.xcConfirm("请至少选中一条记录", window.wxc.xcConfirm.typeEnum.error);
    });
}

function reloadDailyDealOrder() {
    $.ajax({
        url: "/Stock/ReloadPickupDailyDealOrder",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTableForPickUpDailyDealOrder('#DailyDealOrderDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload all daily deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadMyDailyDealOrder() {
    $.ajax({
        url: "/Stock/ReloadMyPickupDailyDealOrder",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content2').html(data);
            initCommonDataTableForPickUpDailyDealOrder('#DailyDealOrderDataTbl2');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload my daily deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadMyDailyDealOrderSummary() {
    $.ajax({
        url: "/Stock/ReloadMyPickupDailyDealOrderSummary",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content3').html(data);
            initCommonDataTable('#DailyDealOrderDataTbl3');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload my daily deal order summary error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadDailyDealOrderByContractNumber(cn) {
    $.ajax({
        url: "/Stock/GetMyDailyDealOrderByContractNumber",
        data: {val: cn},
        type: "POST",
        success: function (data) {
            $('.admin-content4').html(data);
            initCommonDataTable('#DailyDealOrderDataTbl4');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload daily deal order by contract number error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}