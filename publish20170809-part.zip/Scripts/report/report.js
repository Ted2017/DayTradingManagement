﻿function bindReportPageEvent() {
    $(document).on('click', '#downloadBtn', function () {
        var startDate = $("#StartDate").val();
        var endDate = $("#EndDate").val();
        var result = "";
        if (validateDateRange(startDate, endDate)) {
            $.ajax({
                url: "/Report/DownloadReport",
                data: { StartDate: startDate, EndDate: endDate },
                async: false,
                type: "POST",
                success: function (data) {
                    result = data;
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Export report error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            });
            if (result == "Ready")
                window.location.href = 'DownloadCSV?startDate=' + startDate + '&endDate=' + endDate + '';
            else
                window.wxc.xcConfirm("没有相关数据", window.wxc.xcConfirm.typeEnum.info);
            //window.location.href = 'DownloadCSV?startDate=' + startDate + '&endDate=' + endDate + '';
        }
    });
}

function validateDateRange(startDateStr, endDateStr) {
    var valResult = true;
    var startDate = new Date(startDateStr);
    var endDate = new Date(endDateStr);
    if (startDate == null || startDate == 'Invalid Date') {
        valResult = false;
        window.wxc.xcConfirm("请输入正确的起始时间", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (endDate == null || endDate == 'Invalid Date') {
        valResult = false;
        window.wxc.xcConfirm("请输入正确的结束时间", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (endDate.getTime() < startDate.getTime()) {
        valResult = false;
        window.wxc.xcConfirm("起始时间不能大于结束时间", window.wxc.xcConfirm.typeEnum.error);
    }
    return valResult;
}