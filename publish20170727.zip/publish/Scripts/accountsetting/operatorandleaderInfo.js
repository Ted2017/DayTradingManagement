﻿var isOperatorLeaderEdit = false;
var operatorLeaderEditId = 0;
var operatorLeaderGroupId = 0;
var userId = null;
var addOrEdit = "";

var isGroupEdit = false;
var groupEditId = 0;
var gName = "";
var groupAddOrEdit = "";

function bindOperatorLeadManagerEvent() {
    $(document).on('click', '.operatorleader-add-btn', function () {
        addOrEdit = "add";
        $('.addGroupDiv').hide();
        $.ajax({
            url: "/AccountSetting/GetAllGroupsAndEmployeesUnderSupervisor",
            data: {},
            type: "POST",
            async: false,
            success: function (data) {
                var json = eval(data);
                $.each(json, function (index, item) {
                    if (json[index] != null) {
                        if (index == 0) {
                            $('#OperatorLeaderGroup').empty();
                            $('#OperatorLeaderGroup').append('<option value>--请选择--</option>');
                        }
                        else {
                            $('#OperatorLeader').empty();
                            $('#OperatorLeader').append('<option value>--请选择--</option>');
                        }

                        var subjson = json[index];
                        $.each(subjson, function (ind, ite) {
                            if (index == 0)
                                $('#OperatorLeaderGroup').append('<option value=' + subjson[ind].Value + '>' + subjson[ind].Text + '</option>');
                            else
                                $('#OperatorLeader').append('<option value=' + subjson[ind].Value + '>' + subjson[ind].Text + '</option>');
                        })
                    }

                })
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Reload leaders and operators dropdownlist error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });

        if ($('#OperatorLeader option').size() <= 1)
            //alert("没有新员工可以添加分组设置");
            window.wxc.xcConfirm("没有新员工可以添加分组设置", window.wxc.xcConfirm.typeEnum.info);
        else {
            clearAllValues();
            $('#ol_username').prop('style', 'display:none;');
            $('#OperatorLeader').prop('style', 'display:block;');
            $('.addOperatorLeaderDiv').show();
        }
    });

    $(document).on('click', '.group-add-btn', function () {
        groupAddOrEdit = "add";
        clearGroupAllValues();
        $('.addOperatorLeaderDiv').hide();
        $('.addGroupDiv').show();

    });

    $(document).on('click', '.operatorleader-cancel-btn', function () {
        addOrEdit = "";
        clearAllValues();
        $('.addOperatorLeaderDiv').hide();
    });

    $(document).on('click', '.group-cancel-btn', function () {
        groupAddOrEdit = "";
        clearGroupAllValues();
        $('.addGroupDiv').hide();
    });

    $(document).on('click', '.editAction', function () {
        addOrEdit = "edit";
        $('.addOperatorLeaderDiv').show();
        editOperatorLeader(this);
    });

    $(document).on('click', '.deleteAction', function () {
        var olgid = +$(this).closest('tr').data('olid');
        $('.addOperatorLeaderDiv').hide();
        $.ajax({
            url: "/AccountSetting/DeleteEmployeeFromGroup",
            data: { val: olgid },
            type: "POST",
            success: function (data) {
                if (data = "success")
                    reloadOperatorLeader();
                else
                    window.wxc.xcConfirm("删除失败", window.wxc.xcConfirm.typeEnum.error);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Delete employee error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    });

    $(document).on('click', '.editActionGroup', function () {
        groupAddOrEdit = "edit";
        $('.addGroupDiv').show();
        editGroup(this);
    });

    $(document).on('click', '.operatorleader-save-btn', function () {
        saveOperatorLeader();
    });

    $(document).on('click', '.group-save-btn', function () {
        saveGroup();
    });
}

function saveOperatorLeader() {
    if (validateInputs()) {
        var operatorLeaderInfo = getOperatorLeaderInfoObj()
        var operatorLeaderInfoJsonStr = JSON.stringify(operatorLeaderInfo);
        $.ajax({
            url: "/AccountSetting/SaveOperatorLeader",
            data: { OperatorLeaderJsonStr: operatorLeaderInfoJsonStr, IsEdit: isOperatorLeaderEdit },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    $('#OperatorLeader option[value=' + operatorLeaderInfo.UserID + ']').remove();
                    reloadOperatorLeader();
                    clearAllValues();
                    $('.addOperatorLeaderDiv').hide();
                    //location.reload();
                }
                else if (data == 'duplicate')
                    window.wxc.xcConfirm("保存失败，该组组长已存在！", window.wxc.xcConfirm.typeEnum.error);
                else
                    window.wxc.xcConfirm("保存失败，数据异常！", window.wxc.xcConfirm.typeEnum.error);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Save operator or leader info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }   
}

function saveGroup() {
    if (validateGroupInputs()) {
        var groupInfo = getGroupInfoObj()
        var groupInfoJsonStr = JSON.stringify(groupInfo);
        $.ajax({
            url: "/AccountSetting/SaveGroup",
            data: { GroupJsonStr: groupInfoJsonStr, IsEdit: isGroupEdit },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    reloadGroup();
                    clearGroupAllValues();
                    $('.addGroupDiv').hide();
                    //location.reload();
                }
                else if (data == 'duplicate')
                    window.wxc.xcConfirm("保存失败，组名已存在！", window.wxc.xcConfirm.typeEnum.error);
                else
                    window.wxc.xcConfirm("保存失败，数据异常！", window.wxc.xcConfirm.typeEnum.error);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Save group info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
}

function reloadOperatorLeader() {
    $.ajax({
        url: "/AccountSetting/ReloadOperatorLeader",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTable('#OperatorLeaderGroupDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload operator or leader info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadGroup() {
    $.ajax({
        url: "/AccountSetting/ReloadGroup",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content2').html(data);
            initCommonDataTable('#GroupDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload group info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function validateInputs() {
    var valResult = true;
    var operatorOrLeaderUserID = $('#OperatorLeader').val();
    var groupID = $('#OperatorLeaderGroup').val();

    if (userId == null)//add
    {
        if (operatorOrLeaderUserID.Trim() == "") {
            valResult = false;
            window.wxc.xcConfirm("请填选择一个用户名称", window.wxc.xcConfirm.typeEnum.error);
        }
        else if (groupID.Trim() == "") {
            valResult = false;
            window.wxc.xcConfirm("请选择一个组", window.wxc.xcConfirm.typeEnum.error);
        }
    }
    else//edit
    {
        if (groupID.Trim() == "") {
            valResult = false;
            window.wxc.xcConfirm("请选择一个组", window.wxc.xcConfirm.typeEnum.error);
        }
        else if (groupID == operatorLeaderGroupId) {
            valResult = false;
            window.wxc.xcConfirm("未做更改", window.wxc.xcConfirm.typeEnum.info);
        }
    }
    return valResult;
}

function validateGroupInputs() {
    var valResult = true;
    var groupName = $('#g_groupname').val();
    var len = 0;
    for (var i = 0; i < groupName.length; i++) {
        var a = groupName.charAt(i);
        if (a.match(/[^\x00-\xff]/ig) != null) {
            len += 2;
        }
        else {
            len += 1;
        }
    }
    if (groupName.Trim() == "") {
        valResult = false;
        window.wxc.xcConfirm("请填写一个组名", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (len > 50) {
        valResult = false;
        window.wxc.xcConfirm("组名过长", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (gName == groupName) {
        valResult = false;
        window.wxc.xcConfirm("未做更改", window.wxc.xcConfirm.typeEnum.info);
    }
    return valResult
}

function getOperatorLeaderInfoObj() {
    var operatorLeaderInfo = new Object();
    if (isOperatorLeaderEdit) {
        operatorLeaderInfo.ID = operatorLeaderEditId;
    }
    if (addOrEdit == "add")
        operatorLeaderInfo.UserID = $('#OperatorLeader').val();
    else
        operatorLeaderInfo.UserID = userId;
    operatorLeaderInfo.GroupID = $('#OperatorLeaderGroup').val();
    // other fields
    return operatorLeaderInfo;
}

function getGroupInfoObj() {
    var groupInfo = new Object();
    if (isGroupEdit) {
        groupInfo.ID = groupEditId;
    }
    groupInfo.GroupName = $('#g_groupname').val();
    // other fields
    return groupInfo;
}

function editOperatorLeader(obj) {
    var rowObj = $(obj).closest('tr');
    isOperatorLeaderEdit = true;
    operatorLeaderEditId = $(rowObj).data('olid');
    operatorLeaderGroupId = $(rowObj).data('groupid');
    userId = $(rowObj).data('userid')
    $('#OperatorLeader').prop('style', 'display:none;');
    $('#ol_username').prop('style', 'display:block;');
    $('#ol_username').val($(rowObj).data('username'));
    $('#ol_username').prop('disabled', 'disabled');
    $('#OperatorLeaderGroup').val($(rowObj).data('groupid'));
}

function editGroup(obj) {
    var rowObj = $(obj).closest('tr');
    isGroupEdit = true;
    groupEditId = $(rowObj).data('gid');
    gName = $(rowObj).data('ggroupname');
    $('#g_groupname').val($(rowObj).data('ggroupname'));

}

function clearAllValues() {
    $('#OperatorLeader').removeAttr('disabled');
    $('#OperatorLeader').val("");
    $('#OperatorLeaderGroup').val("");
    isOperatorLeaderEdit = false;
    operatorLeaderEditId = 0;
    operatorLeaderGroupId = 0;
}

function clearGroupAllValues() {
    $('#g_groupname').val("");
    isGroupEdit = false;
    groupEditId = 0;
    gName = "";
}