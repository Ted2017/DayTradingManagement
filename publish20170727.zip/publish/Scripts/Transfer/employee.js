﻿function bindTransferPageEvent() {
    $(document).on('click', '.transfer-add-btn', function () {
        var cId = +$('#EmployeeId').val();
        var month = new Date().getMonth();
        if (month < 10)
            month = "0" + month;
        var tDate = new Date().getFullYear() + month;

        $.ajax({
            url: "/Transfer/GetEmployeeProfitInfo",
            data: { userId: cId, tradingDate: tDate },
            type: "POST",
            success: function (data) {
                var jsObject = eval(data);
                $('.transfer-monthprofite').val(jsObject.TradingProfit);
                $('.transfer-monthbase').val(jsObject.MonthBase);
                $('.transfer-monthallowance').val(jsObject.MonthAllowance);
                $('.transfer-monthother').val(jsObject.MonthOthers);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Get employee profit info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
        $('.addTransferOrder').show();
    });

    $(document).on('click', '.transfer-cancel-btn', function () {
        $('.transfer-actualamount').val("");
        $('.transfer-amount').val("");
        $('.transfer-comments').val("");
        $('.addTransferOrder').hide();
    });

    $(document).on('change', '#EmployeeId', function () {
        var cId = +$('#EmployeeId').val();
        var month = new Date().getMonth();
        if (month < 10)
            month = "0" + month;
        var tDate = new Date().getFullYear() + month;

        $.ajax({
            url: "/Transfer/GetEmployeeProfitInfo",
            data: { userId: cId, tradingDate: tDate },
            type: "POST",
            success: function (data) {
                var jsObject = eval(data);
                $('.transfer-monthprofite').val(jsObject.TradingProfit);
                $('.transfer-monthbase').val(jsObject.MonthBase);
                $('.transfer-monthallowance').val(jsObject.MonthAllowance);
                $('.transfer-monthother').val(jsObject.MonthOthers);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Get employee profit info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    });

    $(document).on('click', '.transfer-save-btn', function () {
        if (validateInputs()) {
            var transferOrder = {};
            transferOrder.UserID = +$('#EmployeeId').val();
            transferOrder.Amount = +$('.transfer-amount').val();
            transferOrder.ActualAmount = +$('.transfer-actualamount').val();
            transferOrder.TransferType = +$('#TransferTypeId').val();
            var comments = $('.transfer-comments').val();
            if (comments.Trim() != "") {
                transferOrder.Comments = comments;
            }
            $.ajax({
                url: "/Transfer/AddTransferOrderInfo",
                data: { val: JSON.stringify(transferOrder) },
                type: "POST",
                success: function (data) {
                    if (data = "success") {
                        window.wxc.xcConfirm("保存成功", window.wxc.xcConfirm.typeEnum.success);
                        $('.addTransferOrder').hide();
                        $('.transfer-actualamount').val("");
                        $('.transfer-amount').val("");
                        $('.transfer-comments').val("");
                        reloadTransferOrderDetails();
                    }
                    else
                        window.wxc.xcConfirm("保存失败", window.wxc.xcConfirm.typeEnum.error);
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Save transfer order info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            });
        }
    })
}

function reloadTransferOrderDetails() {
    $.ajax({
        url: "/Transfer/ReloadEmployeeTransferOrderDetails",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTable('#DashboardDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload employee transfer order info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function validateInputs() {
    var actualAmount = $('.transfer-actualamount').val();
    var comments = $('.transfer-comments').val();
    var amount = $('.transfer-amount').val();

    if (actualAmount.Trim() == "") {
        window.wxc.xcConfirm("请填写实转金额", window.wxc.xcConfirm.typeEnum.error);
        return false;
    }
    else if (!IsNumber(actualAmount)) {
        window.wxc.xcConfirm("请输入正确的实转金额", window.wxc.xcConfirm.typeEnum.error);
        return false;
    }
    else {
        if (actualAmount < 0) {
            window.wxc.xcConfirm("请输入正确的实转金额", window.wxc.xcConfirm.typeEnum.error);
            return false;
        }
    }

    if (comments.Trim() != "") {
        var len = 0;
        for (var i = 0; i < comments.length; i++) {
            var a = comments.charAt(i);
            if (a.match(/[^\x00-\xff]/ig) != null) {
                len += 2;
            }
            else {
                len += 1;
            }
        }
        if (len > 200) {
            window.wxc.xcConfirm("备注过长", window.wxc.xcConfirm.typeEnum.error);
            return false;
        }
    }

    if (amount.Trim() == "") {
        window.wxc.xcConfirm("请填写应转金额", window.wxc.xcConfirm.typeEnum.error);
        return false;
    }
    else if (!IsNumber(amount)) {
        window.wxc.xcConfirm("请输入正确的应转金额", window.wxc.xcConfirm.typeEnum.error);
        return false;
    }
    else {
        if (amount < 0) {
            window.wxc.xcConfirm("请输入正确的应转金额", window.wxc.xcConfirm.typeEnum.error);
            return false;
        }
    }

    return true;
}