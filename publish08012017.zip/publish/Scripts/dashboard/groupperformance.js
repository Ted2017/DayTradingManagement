﻿function bindDashboardPageEvent() {
    $(document).on('click', '#reloadBtn', function () {
        reloadDashboardPartial();
    });
}

function reloadDashboardPartial() {
    var tradingMonth = $("#MonthDate").val();

    $.ajax({
        url: "/Dashboard/ReloadGroupPerformanceDashboardPartial",
        data: { val: tradingMonth },
        type: "POST",
        success: function (data) {
            $('.dashboard-partial').html(data);
            initCommonDataTable('#DashboardDataTbl');
            reloadDashboardDonutChart(tradingMonth);
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload dashboard partial error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadDashboardDonutChart(tradingMonth) {
    $.ajax({
        url: "/Dashboard/ReloadGroupPerformanceDashboardDonutChart",
        data: { val: tradingMonth },
        type: "POST",
        success: function (data) {
            if (data.GroupProfits.length > 0) {
                $('#donutChart').remove();
                $('.donutChart-month').append('<canvas id="donutChart" style="height:300px"></canvas>');
                initDashboardDonutChart(data.GroupNames, data.GroupProfits, data.GroupColors);
            }
            else {
                $('#donutChart').remove();
                $('.donutChart-month').append('<canvas id="donutChart" style="height:300px"></canvas>');
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload donut chart error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}



function initDashboardDonutChart(groupName, groupProfit, groupColor) {
    var donutChartCanvas = $("#donutChart").get(0).getContext("2d");
    var donutChart = new Chart(donutChartCanvas);

    var donutChartData = [];
    for (var i = 0; i < groupName.length; i++) {
        var dataset = {};
        dataset.value = groupProfit[i];
        dataset.color = groupColor[i];
        dataset.highlight = groupColor[i];
        dataset.label = groupName[i];
        donutChartData.push(dataset);
    }


    var donutOptions = {
        //Boolean - Whether we should show a stroke on each segment
        segmentShowStroke: true,
        //String - The colour of each segment stroke
        segmentStrokeColor: "#fff",
        //Number - The width of each segment stroke
        segmentStrokeWidth: 2,
        //Number - The percentage of the chart that we cut out of the middle
        percentageInnerCutout: 50, // This is 0 for Pie charts
        //Number - Amount of animation steps
        animationSteps: 100,
        //String - Animation easing effect
        animationEasing: "easeOutBounce",
        //Boolean - Whether we animate the rotation of the Doughnut
        animateRotate: true,
        //Boolean - Whether we animate scaling the Doughnut from the centre
        animateScale: false,
        //Boolean - whether to make the chart responsive to window resizing
        responsive: true,
        // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
        maintainAspectRatio: true,
        //String - A legend template
        legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>"
    };

    donutChart.Doughnut(donutChartData, donutOptions);
}