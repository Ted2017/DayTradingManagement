﻿
function bindRoleManagerEvent() {
    //to do
}

