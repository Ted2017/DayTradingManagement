﻿function bindQuotaPageEvent() {
    $(document).on('click', '.quota-add-btn', function () {
        $('.addEmployeeQuota').show();
    });

    $(document).on('click', '.quota-cancel-btn', function () {
        $('.quota-amount').val("");
        $('.addEmployeeQuota').hide();
    });

    $(document).on('click', '.quota-save-btn', function () {
        if (validateInputs()) {
            var employeeQuota = {};
            employeeQuota.Date = $('.quota-date').val();
            employeeQuota.UserID = $('#EmployeeId').val();
            employeeQuota.Quota = $('.quota-amount').val();

            $.ajax({
                url: "/Quota/AddEmployeeQuotaInfo",
                data: { val: JSON.stringify(employeeQuota) },
                type: "POST",
                success: function (data) {
                    if (data = "success") {
                        window.wxc.xcConfirm("保存成功", window.wxc.xcConfirm.typeEnum.success);
                        $('.addEmployeeQuota').hide();
                        $('.quota-amount').val("");
                        reloadEmployeeQuotaDetails();
                    }
                    else
                        window.wxc.xcConfirm("保存失败", window.wxc.xcConfirm.typeEnum.error);
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Save employee quota info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            });
        }
    });
}

function reloadEmployeeQuotaDetails() {
    $.ajax({
        url: "/Quota/ReloadEmployeeQuotaDetails",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTable('#DashboardDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload employee quota info error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function validateInputs() {
    var quota = $('.quota-amount').val();

    if (quota.Trim() == "") {
        window.wxc.xcConfirm("请填写配资金额", window.wxc.xcConfirm.typeEnum.error);
        return false;
    }
    else if (!IsNumber(quota)) {
        window.wxc.xcConfirm("请输入正确的配资金额", window.wxc.xcConfirm.typeEnum.error);
        return false;
    }
    else {
        if (quota < 0) {
            window.wxc.xcConfirm("请输入正确的配资金额", window.wxc.xcConfirm.typeEnum.error);
            return false;
        }
    }
    return true;
}