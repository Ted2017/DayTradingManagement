﻿
function bindSplitTradingOrderPageEvent() {
    $(document).on('click', '#reloadBtn', function () {
        $('.splitOrderDiv').hide();
        reloadSplitTradingOrder();
    });

    $(document).on('click', '.split-cancel-btn', function () {
        clearAllValues();
        $('.splitOrderDiv').hide();
    });

    $(document).on('click', '.splitAction', function () {
        $('.splitOrderDiv').show();
        splitTradingOrder(this);
    });

    $(document).on('click', '.split-save-btn', function () {
        saveSplitTradingOrder();
    });

    $(document).on('change', '#ClientUserId', function () {
        var uid = $('#ClientUserId').val();

        $.ajax({
            url: "/Balance/GetStocksByUserId",
            data: { userId: uid },
            type: "POST",
            success: function (data) {
                $('#StockId').empty();
                var json = eval(data);
                if (json.length > 0) {
                    //$('#StockId').prop('disabled', false);
                    //$('#reloadBtn').prop('disabled', false);
                    $.each(json, function (index, item) {
                        $('#StockId').append('<option value=' + json[index].Value + '>' + json[index].Text + '</option>');
                    })
                }
                else {
                    $('#StockId').append('<option value="0">没有相关数据</option>');
                    //$('#StockId').prop('disabled', true);
                    //$('#reloadBtn').prop('disabled', true);
                }

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Reload stocks dropdownlist error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    })
}

function reloadSplitTradingOrder() {
    if (validateInputs()) {
        var oprDate = $("#oprDate").val();
        var sid = $('#StockId').val();
        var clientUserId = $('#ClientUserId').val();
        //$('#lbl_oprDate').text($("#oprDate").val());

        //$.ajax({
        //    url: "/Balance/GetFinalAmount",
        //    data: { specificDate: oprDate, stockId: sid },
        //    type: "POST",
        //    success: function (data) {
        //        $('#caculate_bs').show();
        //        $('#lbl_finalAmount').text(data);
        //    },
        //    error: function (XMLHttpRequest, textStatus, errorThrown) {
        //        alert("Reload data error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        //    }
        //});

        $.ajax({
            url: "/Balance/ReloadSplitTradingOrderRedundancyStockPartial",
            data: { specificDate: oprDate, stockId: sid },
            type: "POST",
            async: false,
            success: function (data) {
                $('.dashboard-partial-operator').html(data);
                initCommonDataTable('#DashboardDataRedundancyTbl');
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Reload split trading order redundancy stock partial error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });

        $.ajax({
            url: "/Balance/ReloadSplitTradingOrderPartial",
            data: { specificDate: oprDate, userId: clientUserId, stockId: sid },
            type: "POST",
            async: false,
            success: function (data) {
                $('.dashboard-partial').html(data);
                initCommonDataTable('#DashboardDataTbl');
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Reload split trading order partial error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
    else {
        // to - do
    }
}

function validateInputs() {
    var valResult = true;
    var oprDate = $("#oprDate").val();
    var stockId=$('#StockId').val();

    if (oprDate == null || oprDate == 'Invalid Date') {
        valResult = false;
        window.wxc.xcConfirm("请输入正确的日期", window.wxc.xcConfirm.typeEnum.error);
    }
    else if (stockId == 0) {
        valResult = false;
        window.wxc.xcConfirm("请选择一只证券", window.wxc.xcConfirm.typeEnum.error);
    }

    return valResult;
}

function splitTradingOrder(obj) {
    var rowObj = $(obj).closest('tr');
    $('.tradingorder-id').val($(rowObj).data('tradingorderid'));
    $('.stock-name').text($(rowObj).data('stockname'));
    $('.trading-date').text($(rowObj).data('tradingdate'));
    $('.trading-price').text($(rowObj).data('tradingprice'));
    $('.trading-number').text($(rowObj).data('tradingnumber'));
    var tradingdate = $(rowObj).data('tradingdate').toString().yyyymmddToDate();
    $(".split-date").datepicker("setDate", new Date(tradingdate.setDate(tradingdate.getDate() + 1)));
}

function saveSplitTradingOrder() {
    var tradingOrderId = $('.tradingorder-id').val();
    var splitDate = $('.split-date').val();
    var splitNumber = $('.split-number').val();
    var tradingNumber = $('.trading-number').text();
    if (IsNumber(splitNumber) && +splitNumber <= +tradingNumber && +splitNumber>0 && splitDate != null && splitDate != 'Invalid Date') {
        $.ajax({
            url: "/Balance/SaveSplitTradingOrder",
            data: { TOId: tradingOrderId, SplitDate: splitDate, SplitNumber: splitNumber },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    reloadSplitTradingOrder();
                    clearAllValues();
                    $('.splitOrderDiv').hide();
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Save split trading order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
    else {
        window.wxc.xcConfirm("请输入不大于交易数量的拆分值以及正确的日期", window.wxc.xcConfirm.typeEnum.error);
    }
}

function clearAllValues() {
    $('.tradingorder-id').val('');
    $('.stock-name').text('');
    $('.trading-date').text('');
    $('.trading-price').text('');
    $('.trading-number').text('');
    $('.split-number').val('');
    $('.split-date').val('');
}