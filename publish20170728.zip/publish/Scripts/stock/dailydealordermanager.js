﻿var dailyDeailOrderId = 0;
var contractNumber = 0;

function bindUploadDailyDealOrderEvent() {
    $(document).on('click', '.data-upload-action', function () {
        uploadDailyDealOrderDataFile(this);
    });

    $(document).on('click', '.file-remove-action', function () {
        removeChooseFile(this);
    });
}

function bindDailyDealOrderSummaryPageEvent() {
    $(document).on('click', '#reloadLeaderBtn', function () {
        reloadLeaderDailyDealOrderSummaryPartial();
    });

    $(document).on('click', '#reloadSandMBtn', function () {
        reloadSandMDailyDealOrderSummaryPartial();
    });

    $(document).on('change', '#Groups', function () {
        var gid = $('#Groups').val();

        $.ajax({
            url: "/Dashboard/GetLeadersAndOperatorsByGroupId",
            data: { groupId: gid },
            type: "POST",
            success: function (data) {
                $('#Operators').empty();
                $('#Operators').append('<option value="0">--所有交易员--</option>');
                var json = eval(data);
                $.each(json, function (index, item) {
                    $('#Operators').append('<option value=' + json[index].Value + '>' + json[index].Text + '</option>');
                })
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Reload leaders and operators dropdownlist error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    });
}

function uploadDailyDealOrderDataFile(obj) {
    var fileInputObj = $(obj).parent().find('.trading-order-upload');
    if (fileInputObj.val() == '') {
        window.wxc.xcConfirm("请选择一个正确的数据文件", window.wxc.xcConfirm.typeEnum.error);
    }
    else {
        $('.bg').fadeIn(200);
        $('.loadingcontent').fadeIn(400);
        var formData = new FormData();
        formData.append('resourcetype', fileInputObj.data('resourcetype'));
        formData.append('filename', fileInputObj[0].files[0]);
        $.ajax({
            url: "/Stock/UploadDailyDealOrderDataFile",
            data: formData,
            type: "POST",
            cache: false,
            processData: false,
            contentType: false,
            success: function (data) {
                if (data.substr(0, 2) == '成功') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm(data, window.wxc.xcConfirm.typeEnum.info);
                    removeChooseFile(obj);
                }
                else if (data == 'errorNull') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传失败，文件为空", window.wxc.xcConfirm.typeEnum.error);
                    removeChooseFile(obj);
                }
                else if (data == 'errorWrongHTDataFile') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传失败，请选择正确的海通证券当日成交文件", window.wxc.xcConfirm.typeEnum.error);
                    removeChooseFile(obj);
                }
                else if (data == 'errorWrongZSDataFile') {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    window.wxc.xcConfirm("上传失败，请选择正确的招商证券当日成交文件", window.wxc.xcConfirm.typeEnum.error);
                    removeChooseFile(obj);
                }
                else {
                    $('.bg').fadeOut(800);
                    $('.loadingcontent').fadeOut(800);
                    alert(data);
                    removeChooseFile(obj);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.bg').fadeOut(800);
                $('.loadingcontent').fadeOut(800);
                alert("Upload daily deal order data file error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    }
}

function removeChooseFile(obj) {
    $(obj).parent().find('.trading-order-upload').val('');
}


function bindPickupDailyDealOrderEvent(userid) {
    $(document).on('click', '#allSelectAll', function (event) {
        $(this).closest("th").prop("class", "sorting");
        if ($(this).prop('checked') == true) {
            $("#DailyDealOrderDataTbl").find('input:checkbox').each(function () {
                if ($(this).prop('checked') == false)
                    $(this).prop('checked', true);
            });
        }
        else {
            $("#DailyDealOrderDataTbl").find('input:checkbox').each(function () {
                if ($(this).prop('checked') == true)
                    $(this).prop('checked', false);
            });
        }
        //event.stopPropagation();
    })

    $(document).on('click', '.pickupAction', function () {
        var dealOrders = [];
        var dealOrder = {};
        var cn = $(this).parent().parent().find("td:eq(8)").text();
        dealOrder.ContractNumber = cn;
        dealOrder.StockOperatorUserID = userid;
        dealOrders.push(dealOrder);
        $(this).closest("tr").hide();
        $("#DailyDealOrderDataTbl_info").hide();

        //var defaultVal = $("#DailyDealOrderDataTbl_info").text();
        //var newVal = "";
        //switch (defaultVal.length) {
        //    case 27: {
        //        var oldNum = +defaultVal.substr(13, 1);
        //        var newNum = oldNum - 1;
        //        var reg = new RegExp(oldNum, "g");
        //        newVal = defaultVal.replace(reg, newNum);
        //    }
        //    case 29: {
        //        var oldNum = +defaultVal.substr(13, 2);
        //        var newNum = oldNum - 1;
        //        var reg = new RegExp(oldNum, "g");
        //        newVal = defaultVal.replace(reg, newNum);
        //    }
        //    case 31: {
        //        var oldNum = +defaultVal.substr(13, 3);
        //        var newNum = oldNum - 1;
        //        var reg = new RegExp(oldNum, "g");
        //        newVal = defaultVal.replace(reg, newNum);
        //    }
        //    case 33: {
        //        var oldNum = +defaultVal.substr(13, 4);
        //        var newNum = oldNum - 1;
        //        var reg = new RegExp(oldNum, "g");
        //        newVal = defaultVal.replace(reg, newNum);
        //    }
        //}
        //$("#DailyDealOrderDataTbl_info").text(newVal);
        
        //sInfo

        $.ajax({
            url: "/Stock/BindDealOrderWithOperater",
            data: { val: JSON.stringify(dealOrders) },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    //reloadDailyDealOrder();
                    reloadMyDailyDealOrder();
                    reloadMyDailyDealOrderSummary();
                }
                else {
                    window.wxc.xcConfirm("保存失败", window.wxc.xcConfirm.typeEnum.error);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Binding deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    });

    $(document).on('click', '.pickup-save-btn', function () {
        if ($("#DailyDealOrderDataTbl").find(":checkbox:checked").length > 0) {
            if ($("#DailyDealOrderDataTbl").find(":checkbox:checked").length == 1) {
                if ($("#DailyDealOrderDataTbl").find(":checkbox:checked").prop("id") == "allSelectAll") {
                    window.wxc.xcConfirm("请至少选中一条记录", window.wxc.xcConfirm.typeEnum.error);
                }
                else {
                    var dealOrders = [];
                    $("#DailyDealOrderDataTbl").find(":checkbox:checked").each(function () {
                        var cn = $(this).parent().parent().find("td:eq(8)").text();
                        var dealOrder = {};
                        dealOrder.ContractNumber = cn;
                        dealOrder.StockOperatorUserID = userid;
                        dealOrders.push(dealOrder);
                    });

                    $.ajax({
                        url: "/Stock/BindDealOrderWithOperater",
                        data: { val: JSON.stringify(dealOrders) },
                        type: "POST",
                        success: function (data) {
                            if (data == 'success') {
                                reloadDailyDealOrder();
                                reloadMyDailyDealOrder();
                                reloadMyDailyDealOrderSummary();
                                window.wxc.xcConfirm("保存成功", window.wxc.xcConfirm.typeEnum.success);
                                //window.location.reload();
                            }
                            else {
                                window.wxc.xcConfirm("保存失败", window.wxc.xcConfirm.typeEnum.error);
                            }
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            alert("Binding all deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                        }
                    });
                }
            }
            else {
                var dealOrders = [];
                $("#DailyDealOrderDataTbl").find(":checkbox:checked").each(function () {
                    if ($(this).prop("id") == "allSelectAll") {
                        return true;
                    }    
                    else{
                        var cn = $(this).parent().parent().find("td:eq(8)").text();
                        var dealOrder = {};
                        dealOrder.ContractNumber = cn;
                        dealOrder.StockOperatorUserID = userid;
                        dealOrders.push(dealOrder);
                    }
                });

                $.ajax({
                    url: "/Stock/BindDealOrderWithOperater",
                    data: { val: JSON.stringify(dealOrders) },
                    type: "POST",
                    success: function (data) {
                        if (data == 'success') {
                            reloadDailyDealOrder();
                            reloadMyDailyDealOrder();
                            reloadMyDailyDealOrderSummary();
                            window.wxc.xcConfirm("保存成功", window.wxc.xcConfirm.typeEnum.success);
                            //window.location.reload();
                        }
                        else {
                            window.wxc.xcConfirm("保存失败", window.wxc.xcConfirm.typeEnum.error);
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        alert("Binding all deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                    }
                });
            }
        }
        else
            window.wxc.xcConfirm("请至少选中一条记录", window.wxc.xcConfirm.typeEnum.error);
    });

    $(document).on('click', '.unfoldAction', function () {
        $(".unfold-contract-editdiv").hide();
        contractNumber = +$(this).parent().parent().find("td:eq(8)").text();
        if (contractNumber != 0) {
            $.ajax({
                url: "/Stock/GetMyDailyDealOrderByContractNumber",
                data: { val: contractNumber },
                type: "POST",
                success: function (data) {
                    $('.admin-content4').html(data);
                    initCommonDataTable('#DailyDealOrderDataTbl4');
                    $(".unfold-contract").show();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Load daily deal order by contract number error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            });
        }
        else {
            //to do...
        }
    });

    $(document).on('click', '.splitAction', function () {
        $('.unfold-contract-editdiv').show();
        dailyDeailOrderId = +$(this).closest('tr').data("ddoid");
        $('.stock-name').text($(this).parent().parent().find("td:eq(1)").text());
        $('.trading-date').text($(this).parent().parent().find("td:eq(2)").text());
        $('.trading-type').text($(this).parent().parent().find("td:eq(3)").text());
        $('.trading-price').text($(this).parent().parent().find("td:eq(5)").text());
        $('.trading-number').text($(this).parent().parent().find("td:eq(4)").text());
    });

    $(document).on('click', '.split-save-btn', function () {
        if (dailyDeailOrderId != 0) {
            var tradingNumber = $('.split-number').val();
            if (tradingNumber.Trim() == "" || !(/^[0-9]*[1-9][0-9]*$/.test(tradingNumber.Trim()))) {
                window.wxc.xcConfirm("请填写正确的拆分股数", window.wxc.xcConfirm.typeEnum.error);
            }
            else if (tradingNumber > +$('.trading-number').text()) {
                window.wxc.xcConfirm("拆分股数不能大于成交数量", window.wxc.xcConfirm.typeEnum.error);
            }
            else {
                var uid = +$('#OperatorId').val();
                $.ajax({
                    url: "/Stock/SplitDailyDealOrder",
                    data: { val1: dailyDeailOrderId, val2: uid, val3: tradingNumber },
                    type: "POST",
                    success: function (data) {
                        $('.split-number').val("");
                        $('#OperatorId option:first').prop('selected', 'selected');
                        //$('.unfold-contract-editdiv').hide();
                        //$('.unfold-contract').hide();
                        reloadDailyDealOrderByContractNumber(contractNumber);
                        reloadMyDailyDealOrder();
                        reloadMyDailyDealOrderSummary();
                        $('.trading-number').text(+$('.trading-number').text()-tradingNumber);
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        alert("Split error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                    }
                });
            }
        }
        else {
            //to do...
        }
    });

    $(document).on('click', '.split-cancel-btn', function () {
        $('.split-number').val("");
        $('#OperatorId option:first').prop('selected', 'selected');
        $('.unfold-contract-editdiv').hide();
    });
}

function deletePickupDailyDealOrderEvent(userid) {
    $(document).on('click', '.pickup-delete-btn', function () {
        $(".unfold-contract").hide();
        $(".unfold-contract-editdiv").hide();
        if ($("#DailyDealOrderDataTbl2").find(":checkbox:checked").length != 0) {
            var dealOrders = [];
            $("#DailyDealOrderDataTbl2").find(":checkbox:checked").each(function () {
                var cn = $(this).parent().parent().find("td:eq(8)").text();
                var dealOrder = {};
                dealOrder.ContractNumber = cn;
                dealOrder.StockOperatorUserID = userid;
                dealOrders.push(dealOrder);
            });

            $.ajax({
                url: "/Stock/DeleteDealOrderWithOperater",
                data: { val: JSON.stringify(dealOrders) },
                type: "POST",
                success: function (data) {
                    if (data == 'success') {
                        reloadMyDailyDealOrder();
                        reloadDailyDealOrder();
                        reloadMyDailyDealOrderSummary();
                        window.wxc.xcConfirm("撤销成功", window.wxc.xcConfirm.typeEnum.success);
                        //window.location.reload();
                    }
                    else {
                        window.wxc.xcConfirm("撤销失败", window.wxc.xcConfirm.typeEnum.error);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Deleting my deal order with error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
                }
            });
        }
        else
            window.wxc.xcConfirm("请至少选中一条记录", window.wxc.xcConfirm.typeEnum.error);
    });

    $(document).on('click', '.cancelPickupAction', function () {
        var dealOrders = [];
        var dealOrder = {};
        var cn = $(this).parent().parent().find("td:eq(8)").text();
        dealOrder.ContractNumber = cn;
        dealOrder.StockOperatorUserID = userid;
        dealOrders.push(dealOrder);

        $.ajax({
            url: "/Stock/DeleteDealOrderWithOperater",
            data: { val: JSON.stringify(dealOrders) },
            type: "POST",
            success: function (data) {
                if (data == 'success') {
                    reloadMyDailyDealOrder();
                    reloadDailyDealOrder();
                    reloadMyDailyDealOrderSummary();
                }
                else {
                    window.wxc.xcConfirm("撤销失败", window.wxc.xcConfirm.typeEnum.error);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Deleting my deal order with error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
            }
        });
    });
}

function reloadDailyDealOrder() {
    $.ajax({
        url: "/Stock/ReloadPickupDailyDealOrder",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content').html(data);
            initCommonDataTableForPickUpDailyDealOrder('#DailyDealOrderDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload all daily deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadMyDailyDealOrder() {
    $.ajax({
        url: "/Stock/ReloadMyPickupDailyDealOrder",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content2').html(data);
            initCommonDataTableForPickUpDailyDealOrder('#DailyDealOrderDataTbl2');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload my daily deal order error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadMyDailyDealOrderSummary() {
    $.ajax({
        url: "/Stock/ReloadMyPickupDailyDealOrderSummary",
        data: {},
        type: "POST",
        success: function (data) {
            $('.admin-content3').html(data);
            initCommonDataTableForPickUpDailyDealOrderWithOutOrdering('#DailyDealOrderDataTbl3');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload my daily deal order summary error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadDailyDealOrderByContractNumber(cn) {
    $.ajax({
        url: "/Stock/GetMyDailyDealOrderByContractNumber",
        data: {val: cn},
        type: "POST",
        success: function (data) {
            $('.admin-content4').html(data);
            initCommonDataTable('#DailyDealOrderDataTbl4');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload daily deal order by contract number error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadLeaderDailyDealOrderSummaryPartial() {
    var operatorId = +$('#Operators').val();
    $.ajax({
        url: "/Stock/ReloadLeaderDailyDealOrderSummary",
        data: { OperatorId: operatorId },
        type: "POST",
        success: function (data) {
            $('.daily-summary').html(data);
            initCommonDataTableForPickUpDailyDealOrderWithOutOrdering('#DailyDealOrderDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload leader daily deal order summary error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadSandMDailyDealOrderSummaryPartial() {
    var groupId = +$('#Groups').val();
    var operatorId = +$('#Operators').val();
    $.ajax({
        url: "/Stock/ReloadSandMDailyDealOrderSummary",
        data: { GroupId: groupId, OperatorId: operatorId },
        type: "POST",
        success: function (data) {
            $('.daily-summary').html(data);
            initCommonDataTableForPickUpDailyDealOrderWithOutOrdering('#DailyDealOrderDataTbl');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload SandM daily deal order summary error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}