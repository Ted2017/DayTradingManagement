﻿function bindDashboardPageEvent() {
    $(document).on('click', '#reloadBtn', function () {
        reloadDashboardPartial();
    });
}

function reloadDashboardPartial() {
    var tradingMonth = $("#MonthDate").val();

    $.ajax({
        url: "/Dashboard/ReloadEmployeePerformanceDashboardPartial",
        data: { val: tradingMonth },
        type: "POST",
        success: function (data) {
            $('.dashboard-partial').html(data);
            initCommonDataTable('#DashboardDataTbl');
            reloadDashboardBarChart(tradingMonth);
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload dashboard partial error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}

function reloadDashboardBarChart(tradingMonth) {
    $.ajax({
        url: "/Dashboard/ReloadEmployeePerformanceDashboardBarChart",
        data: { val: tradingMonth },
        type: "POST",
        success: function (data) {
            if (data.EmployeeProfits.length > 0) {
                $('#barChart').remove();
                $('.barChart-month').append('<canvas id="barChart" style="height:300px"></canvas>');
                initDashboardBarChart(data.EmployeeNames, data.EmployeeProfits, data.EmployeeColors);
            }
            else {
                $('#barChart').remove();
                $('.barChart-month').append('<canvas id="barChart" style="height:300px"></canvas>');
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Reload bar chart error! status:" + XMLHttpRequest.status + " readyState:" + XMLHttpRequest.readyState + " textStatus:" + textStatus);
        }
    });
}



function initDashboardBarChart(employeeName, employeeProfit, employeeColor) {
    var barChartCanvas = $("#barChart").get(0).getContext("2d");
    var barChart = new Chart(barChartCanvas);

    //var barChartData = {};
    //var labels = ["员工业绩"];
    //var datasets = [];
    //for (var i = 0; i < employeeName.length; i++) {
    //    var dataset = {};
    //    dataset.label = employeeName[i];
    //    dataset.fillColor = employeeColor[i];
    //    dataset.strokeColor = employeeColor[i];
    //    dataset.pointColor = employeeColor[i];
    //    dataset.pointStrokeColor = "#c1c7d1";
    //    dataset.pointHighlightFill = "#fff";
    //    dataset.pointHighlightStroke = employeeColor[i];
    //    dataset.data = [employeeProfit[i]]
    //    datasets.push(dataset);
    //}
    //barChartData.labels = labels;
    //barChartData.datasets = datasets;

    var barChartData = {
        labels: employeeName,
        datasets: [
          {
              label: "",
              fillColor: "#00a65a",
              strokeColor: "#00a65a",
              pointColor: "#00a65a",
              pointStrokeColor: "#c1c7d1",
              pointHighlightFill: "#fff",
              pointHighlightStroke: "#00a65a",
              data: employeeProfit
          }
        ]
    };

    var barChartOptions = {
        //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
        scaleBeginAtZero: true,
        //Boolean - Whether grid lines are shown across the chart
        scaleShowGridLines: true,
        //String - Colour of the grid lines
        scaleGridLineColor: "rgba(0,0,0,.05)",
        //Number - Width of the grid lines
        scaleGridLineWidth: 1,
        //Boolean - Whether to show horizontal lines (except X axis)
        scaleShowHorizontalLines: true,
        //Boolean - Whether to show vertical lines (except Y axis)
        scaleShowVerticalLines: true,
        //Boolean - If there is a stroke on each bar
        barShowStroke: true,
        //Number - Pixel width of the bar stroke
        barStrokeWidth: 2,
        //Number - Spacing between each of the X value sets
        barValueSpacing: 5,
        //Number - Spacing between data sets within X values
        barDatasetSpacing: 1,
        //String - A legend template
        legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
        //Boolean - whether to make the chart responsive
        responsive: true,
        maintainAspectRatio: true
    };

    barChartOptions.datasetFill = false;
    barChart.Bar(barChartData, barChartOptions);
}